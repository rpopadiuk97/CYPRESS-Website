<?php

session_start();
ob_start();

?>
<html>

<head>
    <?php include './bootstrap.php';?>
    <link rel="stylesheet" href="style.css">
    <title>Liens rapides</title>
</head>

<body>
    <?php include './navbar.php';?>
    <h1 class="text-center"><b>LIENS RAPIDES &gt;&gt;</b></h1>

    <form>

        <?php
            if(!isset($_SESSION['user_id'])){
              echo<<<LOL

              <input type="radio" id="Register" name="Options" value="./register.php">
              <label for="Register">S'inscrire</label><br>
      
              <input type="radio" id="Login" name="Options" value="./login.php">
              <label for="Login">S'identifier</label><br>

              LOL;
            }
            else{
              echo<<<EOL

              <input type="radio" id="Logout" name="Options" value="./doLogout.php">
              <label for="Logout">Se déconnecter</label><br>

              <input type="radio" id="User Profile" name="Options" value="./userProfile.php">
              <label for="User Profile">Profil de l'utilisateur</label><br>

              <input type="radio" id="Report a Problem" name="Options" value="./userReport.php">
              <label for="Report a Problem">Signaler un problème</label><br>

              <input type="radio" id="Reports" name="Options" value="./reports.php">
              <label for="Reports">Rapports</label><br>

              <input type="radio" id="Suggest" name="Options" value="./suggest.php">
              <label for="Suggest">Suggérer</label><br>

              <input type="radio" id="Vote" name="Options" value="./vote.php">
              <label for="Vote">Vote</label><br>

              <input type="radio" id="Survey" name="Options" value="./survey.php">
              <label for="Vote">Enquête</label><br>

              EOL;
              if($_SESSION['role']=='official'){
                echo<<<OFFICIAL
                <input type="radio" id="allReports" name="Options" value="./allReports.php">
                <label for="allReports">Tous les rapports</label><br>
                OFFICIAL;
              }
            }
        ?>

        <input type="radio" id="FAQ" name="Options" value="./FAQ.php">
        <label for="FAQ">FAQ</label><br>

        <input type="radio" id="Contact Us" name="Options" value="./contact.php">
        <label for="Contact Us">Nous contacter</label><br>

        <button type="button" class="btn btn-primary" onclick="window.location = document.querySelector('input[type=radio]:checked').value;">Va</button>
        <br>
        <br>
        

        <img src="img1.jpg" title="" width="25%" height="35%">
        <img src="img2.jpg" width="35%" height="35%">

        <br>
        <br>
        



        <h4>Garder notre ville propre et sûre</h4>
        <button type="button" class="btn btn-info float-right" onclick="prompt('Veuillez entrer votre email de votre ami:','Adresse E-mail');">Partager Cypress avec d'autres</button>


    </form>
</body>

</html>