<?php

session_start();
ob_start();
?>
<html>

<head>
    <?php include './bootstrap.php';?>
    <link rel="stylesheet" href="style.css">
    <title>Vote</title>
</head>

<body>
    <?php include './navbar.php';?>
    <h1 class="text-center"><b>Vote</b></h1>
    <hr>
    <h3 class="text-center">Avez-vous déjà voté?</h3>
    <input type="radio" id="Yes" name="Q1" value="Yes" required>
    <label for="Yes">Oui</label><br></label>
    <input type="radio" id="No" name="Q1" value="No">
    <label for="No">Non</label><br></label>

    <p>Sinon, Voulez-vous voter?</p>
    <input type="radio" id="Already" name="Q2" value="Already" required>
    <label for="Already">J'ai déjà voté</label><br></label>
    <input type="radio" id="Yes1" name="Q2" value="Yes">
    <label for="Yes1">Oui</label><br></label>
    <input type="radio" id="No1" name="Q2" value="No">
    <label for="No1">Non</label><br></label>


    <p>Si vous ne voterez pas, veuillez expliquer pourquoi:</p>

    <input type="radio" id="Voting" name="Q3" value="Voting" required>
    <label for="Voting">Je voterai</label><br></label>

    <input type="radio" id="18plus" name="Q3" value="18plus">
    <label for="18plus">Je n'ai pas 18 ans et plus</label><br></label>

    <input type="radio" id="notCitizen" name="Q3" value="notCitizen">
    <label for="notCitizen">Je ne suis pas un citoyen canadien</label><br></label>

    <input type="radio" id="notInterested" name="Q3" value="notInterested">
    <label for="notInterested">je ne suis pas intéressé</label><br></label>

    <input type="radio" id="nothome" name="Q3" value="nothome">
    <label for="nothome">Je suis hors de la ville / pas à la maison</label><br></label>

    <input type="radio" id="problem" name="Q3" value="problem">
    <label for="problem">Problèmes d'enregistrement</label><br></label>

    <input type="radio" id="far" name="Q3" value="far">
    <label for="far">Zone de vote / Booth est trop loin </label><br></label>

    <input type="radio" id="Transportation" name="Q3" value="Transportation">
    <label for="Transportation">Problèmes de transport </label><br></label>

    <input type="radio" id="busy" name="Q3" value="busy">
    <label for="busy">Les heures de vote sont gênantes pour moi</label><br></label>

    <input type="radio" id="nothing" name="Q3" value="nothing">
    <label for="nothing">Je préfère ne pas le dire</label><br></label>

    <input type="radio" id="other" name="Q3" value="other">
    <label for="other">Autre (veuillez préciser: </label><br></label>

    <textarea id="otherReason" name="otherReason" rows="3" cols="50"></textarea>


    <br></br>
    <input class="btn btn-primary" onclick="alert('Merci d\'avoir voté'); location.href='./portalScreen.php'" type="submit" value="Submit">


</body>

</html>