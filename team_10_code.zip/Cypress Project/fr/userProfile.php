<?php

session_start();
ob_start();
if ( !isset( $_SESSION['user_id'] ) ) {
    header("Location: ./portalScreen.php");
}

$mysqli = new mysqli("fdb29.awardspace.net","3800874_main","nB8JTF2a2T*u4Y+,","3800874_main");

if ($mysqli -> connect_errno){
    echo "Failed to connect to MySQL: " . $mysqli -> connect_errno;
    exit();
}


$commandText = "SELECT * FROM `userinfo` WHERE `id` = ".$_SESSION['user_id'];
$result = $mysqli->query($commandText);
$row=mysqli_fetch_assoc($result);


$fname = ucwords($row['fname']);
$lname = ucwords($row['lname']);
$address = ucwords($row['address']);
$phone = ucwords($row['phone']);
$email = $row['email'];
$username = $row['username'];



?>
<!DOCTYPE html>
<html>

<head>
    <title>Page de profil</title>
    <?php include './bootstrap.php';?>
    <style>
    .title1 {
        font-weight: bold;
        float: left;
    }

    .title2 {
        font-weight: bold;
        float: right;
    }

    .left {
        float: left;
    }
    </style>
</head>

<body style="background-color: beige">
    <?php include './navbar.php';?>
    <h1 class="text-center"><b>informations de l'utilisateur</b></h1>
    <hr>
    <div class="container" id="displayInfo">
        <?php
    echo<<<INFO
    <h4>Prénom: {$fname}</h4>
    <h4>Nom de famille: {$lname}</h4>
    <h4>Adresse: {$address}</h4>
    <h4>Numéro de téléphone: {$phone}</h4>
    <h4>Adresse e-mail: {$email}</h4>
    <h4>Nom d'utilisateur: {$username}</h4>
    <h4>Mot de passe: ***********</h4>
    INFO;
    ?>
    </div>
    <br><br><br>
    <form action="./doChangeDetails.php" method="POST">
        <div class="container">
            <div class="input-group mb-3">
                <div class="input-group-prepend">
                    <span class="input-group-text">Prénom</span>
                </div>
                <input type="text" class="form-control" name="fname" placeholder="Prénom" aria-label="First Name" required>
            </div>

            <div class="input-group mb-3">
                <div class="input-group-prepend">
                    <span class="input-group-text">Nom de famille</span>
                </div>
                <input type="text" class="form-control" name="lname" placeholder="Nom de famille" aria-label="Last Name" required>
            </div>


            <div class="input-group mb-3">
                <div class="input-group-prepend">
                    <span class="input-group-text">Adresse</span>
                </div>
                <input type="text" class="form-control" name="address" placeholder="Adresse" aria-label="Address" required>
            </div>


            <div class="input-group mb-3">
                <div class="input-group-prepend">
                    <span class="input-group-text">Numéro de téléphone</span>
                </div>
                <input type="tel" class="form-control" pattern="[0-9]{10}" minlength="10" maxlength="10" name="phone#" placeholder="Numéro de téléphone" aria-label="Phone Number" required>
            </div>


            <div class="input-group mb-3">
                <div class="input-group-prepend">
                    <span class="input-group-text">E-mail</span>
                </div>
                <input type="email" class="form-control" name="email" placeholder="E-mail" aria-label="Email" required>
            </div>

            <div class="input-group mb-3">
                <div class="input-group-prepend">
                    <span class="input-group-text">Mot de passe</span>
                </div>
                <input type="password" class="form-control" name="password" placeholder="Mot de passe" aria-label="Password" minlength="8" required>
            </div>


            <button class="btn btn-secondary" type="submit" name="changeInfo" value="Change Info" onclick="return confirm('Êtes-vous sûr?')" id="changeInfo">Changer des informations</button>
            <button class="btn btn-danger float-right" type="button" name="deleteAccount" value="deleteAccount" onclick="location.href='./deleteAccount.php'" id="deleteAccount">Supprimer le compte</button>
        </div>
    </form>

</body>

</html>