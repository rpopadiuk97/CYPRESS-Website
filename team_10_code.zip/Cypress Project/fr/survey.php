<?php

session_start();
ob_start();
if ( !isset( $_SESSION['user_id'] ) ) {
    header("Location: ./portalScreen.php");
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Enquête</title>
    <?php include './bootstrap.php';?>
    <link rel="stylesheet" href="style.css">
    <script>
        function redirect(){
            alert('Merci pour votre temps!');
            location.href='./portalScreen.php';

        }
    </script>
</head>

<body>
    <?php include './navbar.php';?>
    <h1 class="text-center"><b>Enquête</b></h1>
    <hr>
    <br>

    <div class="container bg-invisible">
        <form action="./portalScreen.php"> 
            <p>Do you Like Toronto?</p>
            <div class="form-check form-check-inline">
                <input class="form-check-input" type="radio" name="inlineRadioOptions" id="q11" value="Yes">
                <label class="form-check-label" for="q11">Oui</label>
            </div>
            <div class="form-check form-check-inline">
                <input class="form-check-input" type="radio" name="inlineRadioOptions" id="q12" value="No">
                <label class="form-check-label" for="q12">Non</label>
            </div>
            <br><br>
            <div class="form-group">
                <label for="exampleFormControlSelect1">Si vous avez répondu oui, que trouvez-vous le plus convaincant de Toronto?</label>
                <select class="form-control" id="exampleFormControlSelect1">
                    <option>Divertissement</option>
                    <option>Culture et arts</option>
                    <option>Aliments</option>
                    <option>Environnement</option>
                    <option>Sécurité sûreté</option>
                </select>
            </div>
            <div class="form-group">
                <label for="q2">Ou si vous avez répondu non, dites-nous pourquoi</label>
                <textarea class="form-control" id="q2" rows="3"></textarea>
            </div>
            <p>Recommanderiez-vous Cypress à d'autres?</p>
            <div class="form-check form-check-inline">
                <input class="form-check-input" type="radio" name="inlineRadioOptions" id="q31" value="Yes">
                <label class="form-check-label" for="q31">Oui</label>
            </div>
            <div class="form-check form-check-inline">
                <input class="form-check-input" type="radio" name="inlineRadioOptions" id="q32" value="No">
                <label class="form-check-label" for="q32">Non</label>
            </div>
            <br><br>
            <div class="form-group">
                <label for="q4">Avez-vous des commentaires supplémentaires ou des commentaires pour nous?</label>
                <textarea class="form-control" id="q2" rows="3"></textarea>
            </div>
            <br><br>
            <button type="submit" class="btn btn-primary" onclick="redirect();">Soumettre</button>
        </form>
    </div>

</body>

</html>