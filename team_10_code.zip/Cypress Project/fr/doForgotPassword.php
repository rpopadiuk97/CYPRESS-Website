<?php
session_start();


$mysqli = new mysqli("fdb29.awardspace.net","3800874_main","nB8JTF2a2T*u4Y+,","3800874_main");

if ($mysqli -> connect_errno){
    echo "Failed to connect to MySQL: " . $mysqli -> connect_errno;
    exit();
}

if (!isset($_POST['username'],$_POST['secQ'],$_POST['ans'])){
    setcookie("message", "Erreur", time() + (30), "/");
    header("Location: ./forgotPassword.php");
    exit();
}


$commandText = "SELECT * FROM `userinfo` WHERE (`username` = '".$_POST['username']."' OR `email` = '".$_POST['username']."') AND (`secQ` = '".$_POST['secQ']."' AND `ans` = '".$_POST['ans']."')";

$_POST = array();

$result = $mysqli->query($commandText);

if($result && mysqli_num_rows($result)>0){
    setcookie("message", "Compte trouvé, mot de passe envoyé à votre email", time() + (30), "/");
    header("Location: ./forgotPassword.php");
    exit();
}
else{
    setcookie("message", "Le compte d'erreur non trouvé, le nom d'utilisateur et / ou les réponses de sécurité sont incorrects", time() + (30), "/");
    header("Location: ./forgotPassword.php");
    exit();
}

?>