<?php

session_start();
ob_start();
?>
<!DOCTYPE html>
<html>

<head>
    <title>Questions fréquemment posées</title>
    <?php include './bootstrap.php';?>
    <link rel="stylesheet" href="style.css">
    <style>
    .center {
        text-align: center;
    }

    .title1 {
        font-weight: bold;
        float: left;
    }

    .title2 {
        font-weight: bold;
        float: right;
    }

    .button {
        font: bold 11px Arial;
        text-decoration: none;
        background-color: #eeeeee;
        color: #333333;
        padding: 2px 6px 2px 6px;
        border-top: 1px solid #cccccc;
        border-right: 1px solid #333333;
        border-bottom: 1px solid #333333;
        border-left: 1px solid #cccccc;
    }

    .home {
        float: left;
    }
    </style>
</head>

<body style="background-color: antiquewhite">
    <?php include './navbar.php';?>
    <h1 class="text-center"><b>Questions fréquemment posées</b></h1>
    <hr>

    <p><h3>Quel est le but de ce site Web?</h3></p>
    <p>
        Ce site Web est conçu pour nous aider à résoudre les problèmes de la ville le plus<br>
        rapidement possible après avoir reçu votre ou vos rapports. Notre objectif est de parvenir à<br>
        une ville plus durable.
    </p>

    <p><h3>Que dois-je faire si je ne parviens pas à me connecter?</h3></p>
    <p>
        Pour résoudre les problèmes de connexion, veuillez nous contacter à <a href="mailto: support@fakecypress.com">support@fakecypress.com</a>
    </p>

    <p><h3>Comment puis-je modifier les informations de mon compte?</h3></p>
    <p>
        Sur la page du portail, cliquez sur le bouton "Profil utilisateur" et cliquez sur "Aller".<br>
        Vous verrez là un bouton pour modifier vos informations.
    </p>

    <p><h3>Comment supprimer mon compte?</h3></p>
    <p>Cliquez sur le bouton "Profil utilisateur" et un bouton "Supprimer le compte" se trouve dans la partie inférieure de l'écran</p>

    <p><h3>Que faire si je ne trouve pas le type de problème que je voulais signaler?</h3></p>
    <p>
        Cliquez sur le bouton "Suggérer" et laissez votre rapport là-bas ou vous pouvez nous contacter via notre e-mail à 
        <a href="mailto: support@fakecypress.com">support@fakecypress.com</a>
    </p>

    <p><h3>Est-il possible d'annuler un rapport?</h3></p>
    <p>Oui, pour annuler un rapport, cliquez sur le bouton "Rapports". Il y aura une option pour supprimer le (s) rapport (s) que vous avez soumis.</p>
    
    <p><h3>Où puis-je consulter l'historique de mes rapports?</h3></p>
    <p>Allez sur le bouton "Rapports" et vous verrez tous les rapports que vous avez faits.</p>

    <br>
    <br>

    <p>
        Vous ne voyez pas vos questions ici? Ne vous inquiétez pas, veuillez visiter notre page de contact 
        <a href="./contact.php">ici</a>
        pour nos informations
    </p>

</body>

</html>