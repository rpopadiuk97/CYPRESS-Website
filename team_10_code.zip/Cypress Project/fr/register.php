<?php

session_start();
ob_start();
if ( isset( $_SESSION['user_id'] ) ) {
    header("Location: ./portalScreen.php");
}

?>
<!DOCTYPE html>
<html lang="fr">

<head>
    <title>Inscrivez-vous ici</title>
    <?php include './bootstrap.php';?>
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <?php include './navbar.php';?>
    <h1 class="text-center"><b>S'inscrire</b></h1>
    <hr>
    <?php
    if(strlen($_COOKIE["message"])>1) {
        printf("<h1 class=\"text-center text-danger\">%s</h1>",$_COOKIE["message"]);
    }
    setcookie("message", "", time() + (30),"/");

    $_COOKIE=Array();
    if (isset($_SERVER['HTTP_COOKIE'])) {
        $cookies = explode(';', $_SERVER['HTTP_COOKIE']);
        foreach($cookies as $cookie) {
            $parts = explode('=', $cookie);
            $name = trim($parts[0]);
            setcookie($name, '', time()-1000);
            setcookie($name, '', time()-1000, '/');
        }
    }
    ?>

    <b>
        Veuillez entrer des informations ci-dessous: <br>
        Remarque: nom d'utilisateur et mot de passe sont sensibles à la casse
    </b>

    <br>
    <br>
    <br>

    <form action="./doRegister.php" method="POST">

        <label for="fname">Prénom: </label>
        <input type="fname" name="fname" id="fname" required> <br><br>

        <label for="lname">Nom de famille: </label>
        <input type="lname" name="lname" id="lname" required><br><br>

        <label for="address">Adresse: </label>
        <input type="address" name="address" id="address" required><br><br>

        <label for="phone#">Numéro de téléphone:</label>
        <input type="tel" minlength="10" maxlength="10" pattern="[0-9]{10}" name="phone#" id="phone#" required><br><br>

        <label for="email">Adresse e-mail:</label>
        <input type="email" name="email" id="email" required><br><br>

        <label for="username">Nom d'utilisateur: </label>
        <input type="username" name="username" id="username" minlength="4" required><br><br>

        <label for="password">Mot de passe: (8 caractères min) </label>
        <input type="password" name="password" id="password" minlength="8" required><br><br>

        <label for="secQ">Question de sécurité: </label>
        <input type="secQ" name="secQ" id="secQ" required><br><br>

        <label for="ans">Répondre: </label>
        <input type="ans" name="ans" id="ans" required><br><br>

        <label for="role">Rôle: </label>
        <select id="role" name="role" required>
            <option value="user">Utilisateur</option>
            <option value="official">Officiel</option>
        </select>
        <br>

        <button class="btn btn-primary button1">Soumettre</button>
    </form>

</body>

</html>